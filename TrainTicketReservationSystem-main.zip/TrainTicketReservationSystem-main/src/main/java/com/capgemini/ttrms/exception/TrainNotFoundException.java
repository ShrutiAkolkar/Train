package com.capgemini.ttrms.exception;

public class TrainNotFoundException extends RuntimeException{

	public  TrainNotFoundException(String msg) {
		super(msg);
	}
}
