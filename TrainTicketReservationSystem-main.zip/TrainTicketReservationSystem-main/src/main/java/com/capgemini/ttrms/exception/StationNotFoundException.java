package com.capgemini.ttrms.exception;

public class StationNotFoundException extends RuntimeException {
	
	public  StationNotFoundException(String msg) {
		super(msg);
	}

}
